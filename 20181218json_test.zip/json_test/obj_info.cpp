#include "pch.h"
#include <iostream>
#include "obj_info.h"



//�\���̏��ꗗ�擾
const obj_field* obj_get_fields(char* name)
{
	int i;
	for (i = 0; ; i++)
	{
		const char* key = obj_type_names[i];
		if (NULL == key[0]) return NULL;
		if (0 == strcmp(key, name)) return obj_types[i];
	}
}

//�\���̃t�B�[���h�擾
const obj_field* obj_get_field(const obj_field* fields, char* name)
{
	int i;
	for (i = 0; ; i++)
	{
		const obj_field* field = &fields[i];
		const char* key = field->name;
		if (NULL == key[0]) return NULL;
		if (0 == strcmp(key, name)) return field;
	}
}

//�t�B�[���h�ɒl�Z�b�g
void obj_set_field(char* obj, const obj_field* fields, char* name, char* data)
{
	const obj_field* field = obj_get_field(fields, name);
	switch (field->type)
	{
	case TYPE_BYTE:
		*((char*)&obj[field->offset]) = (char)strtol(data, NULL, 0);
		break;

	case TYPE_SHORT:
		*((short*)&obj[field->offset]) = (short)strtol(data, NULL, 0);
		break;

	case TYPE_INT:
		*((int*)&obj[field->offset]) = (int)strtol(data, NULL, 0);
		break;

	case TYPE_LONG:
		*((long*)&obj[field->offset]) = (long)strtol(data, NULL, 0);
		break;

	case TYPE_FLOAT:
		*((float*)&obj[field->offset]) = (float)strtof(data, NULL);
		break;

	case TYPE_DOUBLE:
		*((double*)&obj[field->offset]) = (double)strtod(data, NULL);
		break;

	case TYPE_STR:
		char* pobj = (char*)&obj[field->offset];
		int length = strlen(data) + 1;
		memcpy(pobj, data, length);
		break;
	}
}

//�t�B�[���h�l�擾�i�����������data�ɕԂ��j
void obj_get_field(char* obj, obj_field* fields, char* name, char* data)
{
	const obj_field* field = obj_get_field(fields, name);
	switch (field->type)
	{
	case TYPE_BYTE:
		sprintf_s(data, 16, "%d", *(char*)&obj[field->offset]);
		break;

	case TYPE_SHORT:
		sprintf_s(data, 16, "%d", *(short*)&obj[field->offset]);
		break;

	case TYPE_INT:
		sprintf_s(data, 16, "%d", *(int*)&obj[field->offset]);
		break;

	case TYPE_LONG:
		sprintf_s(data, 16, "%ld", *(long*)&obj[field->offset]);
		break;

	case TYPE_FLOAT:
		sprintf_s(data, 16, "%f", *(float*)&obj[field->offset]);
		break;

	case TYPE_DOUBLE:
		sprintf_s(data, 16, "%lf", *(double*)&obj[field->offset]);
		break;

	case TYPE_STR:
		char* pobj = (char*)&obj[field->offset];
		int length = strlen(pobj) + 1;
		memcpy(data, pobj, length);
		break;
	}
}
