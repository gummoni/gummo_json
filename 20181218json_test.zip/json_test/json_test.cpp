﻿#include "pch.h"
#include <iostream>
#include "obj_info.h"
#include "json_parser.h"


//BASICはここにソースがある
//C:\Users\moni\Documents\Arduino\script_basic


//テスト用構造体
typedef struct
{
	int a;
	char msg[4];
} test_data;

//リフレクションで型（ダミー定義）
const static test_data tmp1;

//test_data構造体フィールド一覧
const static obj_field test_data_fields[] = {
	{ "a"		, TYPE_INT	, FIELD_OFFSET(tmp1, a)		, sizeof(tmp1.a)	, 0		},
	{ "msg"		, TYPE_STR	, FIELD_OFFSET(tmp1, msg)	, sizeof(tmp1.msg)	, 4		},
	{ "\0"		, TYPE_INT	, 0							, 0					, 0		},
};

//全ての構造体定義
const obj_field* obj_types[] =
{
	test_data_fields,
};

//全ての構造体名
const char obj_type_names[][16] = {
	"test_data",
	"test",
	"\0",
};

int main()
{
	char msg[] = "{\"a\" : 123 , \"msg\" : \"hello world\"}";
	printf("hello world....\n");

	test_data tmp;

	int offset = (uint32_t)&tmp;

	json_parse((char*)&tmp, test_data_fields, msg);

	printf("%d\n", tmp.a);
	printf("%s\n", tmp.msg);
	char a;
	scanf_s("%c", &a);
}


void parser_test_data()
{
}



// プログラムの実行: Ctrl + F5 または [デバッグ] > [デバッグなしで開始] メニュー
// プログラムのデバッグ: F5 または [デバッグ] > [デバッグの開始] メニュー

// 作業を開始するためのヒント: 
//    1. ソリューション エクスプローラー ウィンドウを使用してファイルを追加/管理します 
//   2. チーム エクスプローラー ウィンドウを使用してソース管理に接続します
//   3. 出力ウィンドウを使用して、ビルド出力とその他のメッセージを表示します
//   4. エラー一覧ウィンドウを使用してエラーを表示します
//   5. [プロジェクト] > [新しい項目の追加] と移動して新しいコード ファイルを作成するか、[プロジェクト] > [既存の項目の追加] と移動して既存のコード ファイルをプロジェクトに追加します
//   6. 後ほどこのプロジェクトを再び開く場合、[ファイル] > [開く] > [プロジェクト] と移動して .sln ファイルを選択します




