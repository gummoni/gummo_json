#pragma once

//�t�B�[���h�^�C�v
typedef enum
{
	TYPE_BYTE = 0,
	TYPE_SHORT = 1,
	TYPE_INT = 2,
	TYPE_LONG = 3,
	TYPE_FLOAT = 4,
	TYPE_DOUBLE = 5,
	TYPE_STR = 6,
} obj_type;

//�t�B�[���h���
typedef struct
{
	char name[16];
	obj_type type;
	int offset;
	int size;
	int length;
} obj_field;


#define FIELD_OFFSET(obj, field) ((uint32_t)&obj.field - (uint32_t)&obj)


extern const char obj_type_names[][16];
extern const obj_field* obj_types[];

extern const obj_field* obj_get_fields(char* name);
extern const obj_field* obj_get_field(const obj_field* fields, char* name);
extern void obj_set_field(char* obj, const obj_field* fields, char* name, char* data);
extern void obj_get_field(char* obj, obj_field* fields, char* name, char* data);
