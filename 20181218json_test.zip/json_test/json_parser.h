#pragma once
#include "obj_info.h"

typedef struct
{
	char* obj;
	const obj_field* fields;
	char* msg;
	char key[16];
	char val[16];
} json_parse_context;

extern void json_parse(char* obj, const obj_field* fields, char* json_str);
