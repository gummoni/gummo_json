#include "pch.h"
#include <iostream>
#include "json_parser.h"
#include "obj_info.h"

//�󔒍s�X�L�b�v
static bool json_skip_space(json_parse_context* json)
{
	for (; ; json->msg++)
	{
		char ch = *json->msg;
		if (' ' == ch || '\t' == ch) continue;
		if ('\0' == ch) return false;
		return true;
	}
}

//����̕����܂ŃX�L�b�v
static bool json_seek_to(json_parse_context* json, char symbol)
{
	for (; ; json->msg++)
	{
		char ch = *json->msg;
		if ('\0' == ch) return false;
		if (symbol == ch) return true;
	}
}

//�����E������荞��
static bool json_capture_string(json_parse_context* json, char* dst)
{
	bool is_string = false;
	if ('"' == *json->msg)
	{
		json->msg++;
		is_string = true;
	}

	int index = 0;
	bool ignore_flg = false;
	for (;; json->msg++)
	{
		char ch = *json->msg;
		switch (ch)
		{
		case '\\':
			json->msg++;
			ch = *json->msg;
			switch (ch)
			{
			case 't':
				dst[index++] = '\t';
				break;
			case 'r':
				dst[index++] = '\r';
				break;
			case 'n':
				dst[index++] = '\n';
				break;
			case '0':
				dst[index++] = '\0';
				break;
			default:
				dst[index++] = ch;
				break;
			}
			break;

		case ' ':	case '\t':
			if (is_string)
			{
				dst[index++] = ch;
			}
			else
			{
				dst[index] = '\0';
				return true;
			}
			break;

		case ':':	case ',':	case '}':	case ']':
			//������荞�ݏI��
			dst[index] = '\0';
			return true;

		case '"':
			//������荞�ݏI��
			json->msg++;
			dst[index] = '\0';
			return true;

		case '\0':
			//�I�[
			return false;

		default:
			//�������
			dst[index++] = ch;
			break;
		}
	}
}

//��͂��̂P
static bool json_check_value_style_start(json_parse_context* json)
{
	char ch = *json->msg;
	switch (ch)
	{
	case '{':
		//model: key : value
		json->msg++;
		for (;;)
		{
			if (!json_skip_space(json)) return false;
			if (!json_capture_string(json, json->key)) return false;
			if (!json_skip_space(json)) return false;
			if (':' != *json->msg) return false;
			json->msg++;
			if (!json_skip_space(json)) return false;
			if (!json_capture_string(json, json->val)) return false;
			if (!json_skip_space(json)) return false;
			printf("%s = %s\n", json->key, json->val);
			obj_set_field(json->obj, json->fields, json->key, json->val);

			//next
			switch (*json->msg)
			{
			case ',':
				//����
				json->msg++;
				continue;

			case '}':
				//�I��
				json->msg++;
				return true;
			}
		}
		break;
	case '[':
		//array  TODO
		break;
		return false;

	default:
		return false;
	}
}

void json_parse(char* obj, const obj_field* fields, char* json_str)
{
	json_parse_context context;
	context.obj = obj;
	context.fields = fields;
	context.msg = json_str;
	for (;;)
	{
		if (!json_check_value_style_start(&context)) return;
	}
}
