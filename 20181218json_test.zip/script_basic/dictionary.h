#ifndef __DICTIONARY_H__
#define __DICTIONARY_H__
#include "config.h"

extern void dic_clear(void);
extern char* dic_get(char*);
extern void dic_set(char*, char*);


#endif//__DICTIONARY_H__
