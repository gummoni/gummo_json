#ifndef __RPN_H__
#define __RPN_H__

extern void rpn_reset(void);
extern void rpn_decode(int value);
extern int rpn_result(void);

#endif//__RPN_H__
