#ifndef __SCRIPT_DECODER_H__
#define __SCRIPT_DECODER_H__

extern int decoder_execute(void);

#endif//__SCRIPT_DECODER_H__
