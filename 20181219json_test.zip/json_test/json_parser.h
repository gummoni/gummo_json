#pragma once

//�\���̃C���f�b�N�X�i���̒l���\��A���̒l�����[�U��`�j
typedef enum
{
	TYPE_INDEX_STRING = -7,
	TYPE_INDEX_DOUBLE = -6,
	TYPE_INDEX_FLOAT = -5,
	TYPE_INDEX_LONG = -4,
	TYPE_INDEX_INT = -3,
	TYPE_INDEX_SHORT = -2,
	TYPE_INDEX_BYTE = -1,
	//���[�U�^�C�v��`
	TYPE_INDEX_TEST1_DATA = 0,
	TYPE_INDEX_TEST2_DATA = 1,
	TYPE_INDEX_MAX,
} TYPE_INDEX;

//�t�B�[���h���
typedef struct
{
	char name[16];
	TYPE_INDEX type;
	uint32_t offset;
	uint8_t size;
	uint8_t length;
} obj_field;

typedef struct
{
	char* obj;
	const obj_field* fields;
	char* msg;
	char key[16];
	char val[16];
} json_parse_context;


#define FIELD_OFFSET(obj, field) ((uint32_t)&obj.field - (uint32_t)&obj)
#define FIELD_INFO(obj, name, type, length)	{ #name, type, FIELD_OFFSET(obj, name), sizeof(obj.name), length }
#define FIELD_END() { "\0", TYPE_INDEX_BYTE, 0, 0, 0 }

extern const char* obj_type_names[];
extern const obj_field* obj_types[];

extern const obj_field* obj_get_fields(TYPE_INDEX index);
extern const obj_field* obj_get_field(const obj_field* fields, char* name);
extern void* obj_get_field_pointer(char* obj, const obj_field* field);
extern void obj_set_value(char* pval, TYPE_INDEX index, char* data);
extern void obj_set_field(char* obj, const obj_field* fields, char* name, char* data);

extern char* json_deserialize(void* obj, const obj_field* fields, char* json_str);
extern int json_serialize(void* obj, const obj_field* fields, char* json_str);
