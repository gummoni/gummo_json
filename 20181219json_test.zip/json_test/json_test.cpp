﻿#include "pch.h"
#include <iostream>
#include "json_parser.h"
#include "mqtt.h"

//BASICはここにソースがある
//C:\Users\moni\Documents\Arduino\script_basic


//テスト用構造体
typedef struct
{
	unsigned short b[2];
	char msg[16];
} test2_data;

typedef struct
{
	int a;
	test2_data data[2];
	char msg[16];
} test1_data;


//全ての構造体名
const char test1_data_name[] = "test1_data";
const char test2_data_name[] = "test2_data";

const char* obj_type_names[] = {
	test1_data_name,
	test2_data_name,
};

//変数定義
static test1_data tmp1;

//test_data構造体フィールド一覧
const static obj_field test1_data_fields[] = {
	FIELD_INFO(tmp1			, a		, TYPE_INDEX_INT		, 1		),
	FIELD_INFO(tmp1			, data	, TYPE_INDEX_TEST2_DATA	, 2		),
	FIELD_INFO(tmp1			, msg	, TYPE_INDEX_STRING		, 16	),
	FIELD_END()
};

//test2_data構造体フィールド一覧
const static obj_field test2_data_fields[] = {
	FIELD_INFO(tmp1.data[0]	, b		, TYPE_INDEX_SHORT		, 2		),
	FIELD_INFO(tmp1.data[0]	, msg	, TYPE_INDEX_STRING		, 16	),
	FIELD_END()
};

//全ての構造体定義
const obj_field* obj_types[] =
{
	test1_data_fields,
	test2_data_fields,
};

//メイン処理
int main()
{
	char json_data[512];
	char msg[] = "{\"a\" : 123 , \"data\" :[{ \"b\": [ 64 , 12 ], \"msg\" : \"foo bar\" },{ \"b\": [ 22 , 99 ], \"msg\" : \"unko\" }],  \"msg\" : \"hello world\"}";
	char str1[] = "S/GROUP/NAME/COMMAND/PARAMETER";
	char str2[] = "S/GROUP/NAME/COMMAND";
	int offset = (uint32_t)&tmp1;
	char a;

	//JSON->OBJ化
	json_deserialize(&tmp1, test1_data_fields, msg);

	//OBJ->JSON化
	json_serialize(&tmp1, test1_data_fields, json_data);

	//MQTT解析
	mqtt_packet p1 = mqtt_parse(str1);
	mqtt_packet p2 = mqtt_parse(str2);

	//出力チェック
	printf("---deserialize---\n");
	printf("test1_data.a = %d\n", tmp1.a);
	printf("test1_data.msg = %s\n", tmp1.msg);
	printf("test1_data.data[0].b[0] = %d\n", tmp1.data[0].b[0]);
	printf("test1_data.data[0].b[1] = %d\n", tmp1.data[0].b[1]);
	printf("test1_data.data[0].msg = %s\n",  tmp1.data[0].msg);
	printf("test1_data.data[1].b[0] = %d\n", tmp1.data[1].b[0]);
	printf("test1_data.data[1].b[1] = %d\n", tmp1.data[1].b[1]);
	printf("test1_data.data[1].msg = %s\n",  tmp1.data[1].msg);
	printf("---serialize---\n");
	printf("%s\n", json_data);
	scanf_s("%c", &a, 256);
}
