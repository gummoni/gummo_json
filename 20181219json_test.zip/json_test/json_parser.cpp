#include "pch.h"
#include <iostream>
#include "json_parser.h"

static bool json_capture(json_parse_context* context, char* dst);

//�\���̏��ꗗ�擾
const obj_field* obj_get_fields(TYPE_INDEX index) { return (0 > index) ? NULL : obj_types[index]; }

//�\���̃t�B�[���h�̃C���X�^���X�|�C���^�擾
void* obj_get_field_pointer(char* obj, const obj_field* field) { return (0 > field) ? NULL : &obj[field->offset]; }

//�\���̃t�B�[���h�擾
const obj_field* obj_get_field(const obj_field* fields, char* name)
{
	for (const obj_field* field = fields; NULL != field; field++)
	{
		const char* key = field->name;
		if (0 == strcmp(key, name)) return field;
	}
	return NULL;
}

//�I�u�W�F�N�g�ɒl�Z�b�g
void obj_set_value(char* pval, TYPE_INDEX type, char* data)
{
	if (type == TYPE_INDEX_BYTE) *((unsigned char*)pval) = (unsigned char)strtol(data, NULL, 0);
	else if (type == TYPE_INDEX_SHORT) *((unsigned short*)pval) = (unsigned short)strtol(data, NULL, 0);
	else if (type == TYPE_INDEX_INT) *((unsigned int*)pval) = (unsigned int)strtol(data, NULL, 0);
	else if (type == TYPE_INDEX_LONG) *((unsigned long*)pval) = (unsigned long)strtol(data, NULL, 0);
	else if (type == TYPE_INDEX_FLOAT) *((float*)pval) = (float)strtof(data, NULL);
	else if (type == TYPE_INDEX_DOUBLE) *((double*)pval) = (double)strtod(data, NULL);
	else if (type == TYPE_INDEX_STRING)
	{
		int length = strlen(data) + 1;
		memcpy(pval, data, length);
	}
}

//�t�B�[���h�ɒl�Z�b�g
void obj_set_field(char* obj, const obj_field* fields, char* name, char* data)
{
	if ((1 < fields->length) && (TYPE_INDEX_STRING != fields->type)) return;	//�z��̎��̓X�L�b�v
	const obj_field* pfield = obj_get_field(fields, name);
	if (NULL == pfield) return;
	if (0 <= pfield->type) return;
	char* pval = &obj[pfield->offset];
	TYPE_INDEX type = pfield->type;
	obj_set_value(pval, type, data);
}

//�󔒍s�X�L�b�v
static bool json_skip_space(json_parse_context* context)
{
	for (; ; context->msg++)
	{
		char ch = *context->msg;
		if (' ' == ch || '\t' == ch) continue;
		if ('\0' == ch) return false;
		return true;
	}
}

//�����擾
static bool json_capture_numeric(json_parse_context* context, char* dst)
{
	for (char ch = *context->msg; ; ch = *(++context->msg), dst++)
	{
		if (('0' <= ch && ch <= '9') || ('x' == ch) || ('.' == ch) || ('a' <= ch && ch <= 'f') || ('A' <= ch && ch <= 'F'))
		{
			*dst = ch;
		}
		else
		{
			*dst = '\0';
			json_skip_space(context);
			return ('\0' != ch);
		}
	}
}

//������擾
static bool json_capture_string(json_parse_context* context, char* dst)
{
	bool ignore_flg = false;
	context->msg++;	// �u"�v�X�L�b�v
	for (char ch = *context->msg; '\0' != ch; ch = *(++context->msg), dst++)
	{
		switch (ch)
		{
		case '\\':
			ch = *(++context->msg);
			if (ch == 'a') *dst = '\a';
			else if (ch == 'b') *dst = '\b';
			else if (ch == 'f') *dst = '\f';
			else if (ch == 'n') *dst = '\n';
			else if (ch == 'r') *dst = '\r';
			else if (ch == 't') *dst = '\t';
			else if (ch == 'v') *dst = '\v';
			else if (ch == '0') *dst = '\0';
			else *dst = ch;
			break;

		case '"':
			*dst = '\0';
			context->msg++;
			json_skip_space(context);
			return true;

		default:
			*dst = ch;
			break;
		}
	}
	return false;
}

//�I�u�W�F�N�g��荞��
static bool json_capture_model(json_parse_context* context, char* dst)
{
	json_skip_space(context);
	const obj_field* pfield = obj_get_field(context->fields, context->key);
	void* pobj = obj_get_field_pointer(context->obj, pfield);
	const obj_field* pfields = obj_get_fields(pfield->type);
	if (0 > pfields->size) return false;
	context->msg = json_deserialize(pobj, pfields, context->msg);
	return true;
}

//�z���荞��
static bool json_capture_array(json_parse_context* context)
{
	context->msg++;
	json_skip_space(context);
	char* pname = context->key;
	const obj_field* pfield = obj_get_field(context->fields, pname);
	int length = pfield->length;
	int array_size = pfield->size / length;
	char* pobj = (char*)obj_get_field_pointer(context->obj, pfield);
	TYPE_INDEX type = pfield->type;

	int array_length = pfield->length;
	for (; ']' != *context->msg; pobj += array_size)
	{	//TODO:�o�b�t�@�I�[�o�[�����΍�
		if (0 > type)
		{	//�ʏ�̌^
			if (!json_capture(context, context->val)) break;
		}
		else
		{	//���[�U�^
			const obj_field* pfields = obj_get_fields(type);
			context->msg = json_deserialize(pobj, pfields, context->msg);
		}
		if (0 <= array_length)
		{
			array_length--;
			obj_set_value(pobj, type, context->val);
		}
		json_skip_space(context);
		char ch = *context->msg;
		if (',' == ch)
		{
			context->msg++;
			json_skip_space(context);
		}
		else if (']' == ch)
		{
			context->msg++;
			break;
		}
	}
	return true;
}

//�����E������荞��
static bool json_capture(json_parse_context* context, char* dst)
{
	if ('"' == *context->msg) return json_capture_string(context, dst);
	else if ('{' == *context->msg) return json_capture_model(context, dst);
	else if ('[' == *context->msg) return json_capture_array(context);
	else return json_capture_numeric(context, dst);
}

//key:value ��荞��
static bool json_read_model(json_parse_context* context)
{
	context->msg++;
	for (;;)
	{
		if (!json_skip_space(context)) return false;
		if (!json_capture_string(context, context->key)) return false;
		if (!json_skip_space(context)) return false;
		if (':' != *context->msg) return false;
		context->msg++;
		if (!json_skip_space(context)) return false;
		if (!json_capture(context, context->val)) return false;
		if (!json_skip_space(context)) return false;
		//printf("%s = %s\n", context->key, context->val);
		const obj_field* pfield = obj_get_field(context->fields, context->key);
		obj_set_field(context->obj, pfield, context->key, context->val);

		//next
		switch (*context->msg)
		{
		case ',':
			//����
			context->msg++;
			continue;

		case '}':
			//�I��
			context->msg++;
			return true;
		}
	}
}

//JSON������
static int json_to_string_value(char* pval, TYPE_INDEX index, char* msg)
{
	if (index == TYPE_INDEX_BYTE) return sprintf_s(msg, 16, "%d", *(unsigned char*)pval);
	else if (index == TYPE_INDEX_SHORT) return sprintf_s(msg, 16, "%d", *(unsigned short*)pval);
	else if (index == TYPE_INDEX_INT) return sprintf_s(msg, 16, "%d", *(unsigned int*)pval);
	else if (index == TYPE_INDEX_LONG) return sprintf_s(msg, 16, "%ld", *(unsigned long*)pval);
	else if (index == TYPE_INDEX_FLOAT) return sprintf_s(msg, 16, "%f", *(float*)pval);
	else if (index == TYPE_INDEX_DOUBLE) return sprintf_s(msg, 16, "%lf", *(double*)pval);
	else if (index == TYPE_INDEX_STRING) return sprintf_s(msg, 256, "\"%s\"", pval);
	else
	{	//���[�U��`
		const obj_field* pfields = obj_get_fields(index);
		return json_serialize(pval, pfields, msg);
	}
}

//JSON�����񉻁i�T�u�����j
static int json_to_string(json_parse_context* context)
{
	int idx = 0;
	idx += sprintf_s(context->msg, 256, "{");
	const obj_field* pfield = context->fields;
	char* pmsg = context->msg;

	for (;;)
	{
		int length = pfield->length;
		TYPE_INDEX type = pfield->type;
		char* pobj = &context->obj[pfield->offset];

		//key
		idx += sprintf_s(&pmsg[idx], 256, "\"%s\":", pfield->name);

		//value
		if ((1 < length) && (TYPE_INDEX_STRING != type))
		{	//array
			int length = pfield->length;
			int array_size = pfield->size / length;
			idx += sprintf_s(&pmsg[idx], 16, "[");
			int i = 0;
			for (;;)
			{
				idx += json_to_string_value(pobj, type, &pmsg[idx]);

				//next
				pobj += array_size;
				if (++i == length) break;
				idx += sprintf_s(&pmsg[idx], 16, ",");
			}
			idx += sprintf_s(&pmsg[idx], 16, "]");
		}
		else
		{	//model
			idx += json_to_string_value(pobj, type, &pmsg[idx]);
		}

		//next
		pfield++;
		if (NULL == *pfield->name) break;
		idx += sprintf_s(&pmsg[idx], 256, ",");
	}
	idx += sprintf_s(&pmsg[idx], 256, "}");
	context->msg[idx] = '\0';
	return idx;
}


//JSON�f�V���A���C�Y�iOBJ���j
char* json_deserialize(void* obj, const obj_field* fields, char* json_str)
{
	json_parse_context context;
	context.obj = (char*)obj;
	context.fields = fields;
	context.msg = json_str;

	switch (*context.msg)
	{
	case '{':	return (!json_read_model(&context)) ? NULL : context.msg;
	case '[':	return (!json_capture_array(&context)) ? NULL : context.msg;
	default:	return NULL;
	}
}

//JSON�V���A���C�Y�i�����񉻁j
int json_serialize(void* obj, const obj_field* fields, char* json_str)
{
	json_parse_context context;
	context.obj = (char*)obj;
	context.fields = fields;
	context.msg = json_str;
	return json_to_string(&context);
}
